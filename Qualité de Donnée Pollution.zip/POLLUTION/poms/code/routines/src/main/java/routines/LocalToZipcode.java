package routines;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import routines.system.JSONArray;
import routines.system.JSONObject;

public class LocalToZipcode {
	 public static  String  convert (String cord ) throws IOException, IOException
	    {
	        	String str = cord ; 
	        	if(cord  == null )  return null ; 
	        	String [] parts = str.split(",");
	            if(parts.length < 2) return null;
	            System.out.println(parts[0]);
	            System.out.println(parts[1]);
	    
	            parts[0] = parts[0].trim() ; 
	            parts[1] = parts[1].trim() ; 
	      
	        try 
	        {
	                
			        URL url = new URL("https://api-adresse.data.gouv.fr/reverse/?lon=" +parts[1]+"&lat="+parts[0]);
			        String res = ""; 

	                
			        try (BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8")))
			        {
			            for (String line; (line = reader.readLine()) != null;) 
			            {
			                     res +=  (" "+ line) ;
			            }
			            
			            JSONObject obj = new  JSONObject(res);
			            System.out.println(obj.get("features").toString());
			            JSONArray a = new JSONArray(obj.get("features").toString());
			     
			
			            JSONObject node1 =  new JSONObject(a.get(0).toString());
			            
			            JSONObject node2 = new JSONObject( node1.get("properties").toString());
			            String data = node2.get("postcode").toString();
			        
			            return data ;
			
			            
			        } 
	       
	        	}
	            catch (Exception e) 
	        	{
	        
	              return null; 	
	            }


			
	    }

}
