package routines;

public class matcher {
    public static boolean matchMail(String message) {
        if (message == null) {
            return false;
        }
        if(message.toLowerCase().matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
        	return true;
        }
        return false;
    }
    
    public static boolean matchPhone(String tel) {
    	 if(tel.replaceAll(" ","").length() < 10 || tel.replaceAll(" ","").length() >= 12 ) return false;
    	 return true;
    }
    
    public static boolean matchIDCapteur(String idcapteur) {
	   	 if (idcapteur == null) {
	            return false;
	        }
	        if(idcapteur.toLowerCase().matches("[a-z]+[0-9]+")) return true;
	        return false;
   }
    public static boolean matchlocalisation(String loc) {
    	if(loc != null) {
    		if (!loc.contains(",")) {
	            return true;
	        }
    	}
	        return false;
  } 
   
    
}
